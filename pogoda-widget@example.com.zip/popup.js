// === КОНСТАНТЫ ===
const CACHE_DURATION = 5 * 60 * 1000; // 5 минут
const AUTO_UPDATE_INTERVAL = 5 * 60 * 1000; // 5 минут

const POPULAR_CITIES = [
    { name: 'Москва', country: 'Россия', lat: 55.7558, lon: 37.6173 },
    { name: 'Санкт-Петербург', country: 'Россия', lat: 59.9343, lon: 30.3351 },
    { name: 'Новосибирск', country: 'Россия', lat: 55.0084, lon: 82.9357 },
    { name: 'Екатеринбург', country: 'Россия', lat: 56.8389, lon: 60.6057 },
    { name: 'Казань', country: 'Россия', lat: 55.7887, lon: 49.1221 },
    { name: 'Сургут', country: 'Россия', lat: 61.2574, lon: 73.4178 },
    { name: 'Нижний Новгород', country: 'Россия', lat: 56.2965, lon: 43.9361 },
    { name: 'Челябинск', country: 'Россия', lat: 55.1644, lon: 61.4368 },
    { name: 'Самара', country: 'Россия', lat: 53.1959, lon: 50.1008 },
    { name: 'Омск', country: 'Россия', lat: 54.9885, lon: 73.3242 }
];

const storage = {
    get: (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve)),
    set: (data) => new Promise(resolve => chrome.storage.local.set(data, resolve)),
    remove: (keys) => new Promise(resolve => chrome.storage.local.remove(keys, resolve))
};

// === КОНВЕРТАЦИЯ ЕДИНИЦ ===
function convertTemp(celsius, unit) {
    if (unit === 'f') return Math.round(celsius * 9/5 + 32);
    return Math.round(celsius);
}

function convertWind(kmh, unit) {
    if (unit === 'ms') return (kmh / 3.6).toFixed(1);
    if (unit === 'mph') return (kmh * 0.621371).toFixed(1);
    return Math.round(kmh);
}

function getWindUnitLabel(unit) {
    if (unit === 'ms') return 'м/с';
    if (unit === 'mph') return 'миль/ч';
    return 'км/ч';
}

function convertPressure(hpa, unit) {
    if (unit === 'mmhg') return Math.round(hpa * 0.75006);
    if (unit === 'inhg') return (hpa * 0.02953).toFixed(2);
    return Math.round(hpa);
}

function getPressureUnitLabel(unit) {
    if (unit === 'mmhg') return 'мм';
    if (unit === 'inhg') return 'inHg';
    return 'гПа';
}

function getTempUnitLabel(unit) {
    return unit === 'f' ? '°F' : '°C';
}

// === КОНВЕРТАЦИЯ КОДОВ ПОГОДЫ ===
function convertWttrCode(code) {
    const codeMap = {
        '113': 0, '116': 1, '119': 2, '122': 3,
        '143': 45, '176': 61, '179': 71, '182': 65,
        '185': 65, '200': 95, '227': 71, '230': 75,
        '248': 45, '260': 45, '263': 51, '266': 51,
        '281': 55, '284': 55, '293': 61, '296': 61,
        '299': 63, '302': 63, '305': 65, '308': 65,
        '311': 65, '314': 65, '317': 65, '320': 71,
        '323': 71, '326': 71, '329': 73, '332': 73,
        '335': 75, '338': 75, '350': 65, '353': 61,
        '356': 63, '359': 65, '362': 65, '365': 65,
        '368': 71, '371': 73, '374': 65, '377': 65,
        '386': 95, '389': 95, '392': 71, '395': 75
    };
    return codeMap[code] || 0;
}

function convert7TimerCode(code) {
    const codeMap = {
        'clear': 0, 'pcloudy': 2, 'mcloudy': 3,
        'cloudy': 3, 'overscst': 3, 'rain': 63,
        'lightrain': 61, 'hrain': 65, 'tsrain': 95,
        'snow': 73, 'lsnow': 71, 'hsnow': 75,
        'fog': 45
    };
    return codeMap[code] || 0;
}

// === API 1: Open-Meteo ===
async function fetchFromOpenMeteo(lat, lon) {
    const SERVERS = [
        'https://api-us.open-meteo.com/v1/forecast',
        'https://api.open-meteo.com/v1/forecast',
        'https://api-eu.open-meteo.com/v1/forecast'
    ];

    const params = `latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,pressure_msl` +
        `&hourly=temperature_2m,weather_code` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,wind_speed_10m_max` +
        `&forecast_days=7&timezone=auto`;

    const controllers = SERVERS.map(() => new AbortController());
    
    const fetchPromises = SERVERS.map((server, index) => {
        return new Promise(async (resolve) => {
            const timeout = 4000;
            const timeoutId = setTimeout(() => {
                controllers[index].abort();
                resolve({ success: false, server });
            }, timeout);
            
            try {
                const url = `${server}?${params}`;
                const response = await fetch(url, { 
                    signal: controllers[index].signal,
                    headers: { 'Accept': 'application/json' }
                });
                
                clearTimeout(timeoutId);
                
                if (response.ok) {
                    const data = await response.json();
                    console.log('✅ Open-Meteo:', server);
                    controllers.forEach((ctrl, i) => { if (i !== index) ctrl.abort(); });
                    resolve({ success: true, data, server });
                    return;
                }
                resolve({ success: false, server });
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name !== 'AbortError') console.log('❌ Open-Meteo:', server);
                resolve({ success: false, server });
            }
        });
    });

    const results = await Promise.all(fetchPromises);
    const success = results.find(r => r.success);
    return success ? success.data : null;
}

// === API 2: wttr.in ===
async function fetchFromWttr(lat, lon) {
    try {
        console.log('🔄 Пробуем wttr.in...');
        const url = `https://wttr.in/${lat},${lon}?format=j1&lang=ru`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        
        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'Accept': 'application/json' }
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ wttr.in работает!');
            
            const current = data.current_condition[0];
            const weather = data.weather[0];
            
            return {
                current: {
                    temperature_2m: parseFloat(current.temp_C),
                    relative_humidity_2m: parseInt(current.humidity),
                    apparent_temperature: parseFloat(current.FeelsLikeC),
                    wind_speed_10m: parseFloat(current.windspeedKmph),
                    weather_code: convertWttrCode(current.weatherCode),
                    pressure_msl: parseInt(current.pressure)
                },
                hourly: {
                    time: weather.hourly.map(h => `${weather.date}T${h.time.toString().padStart(4, '0')}`),
                    temperature_2m: weather.hourly.map(h => parseInt(h.tempC)),
                    weather_code: weather.hourly.map(h => convertWttrCode(h.weatherCode))
                },
                daily: {
                    time: data.weather.map(w => w.date),
                    weather_code: data.weather.map(w => convertWttrCode(w.hourly[4].weatherCode)),
                    temperature_2m_max: data.weather.map(w => parseInt(w.maxtempC)),
                    temperature_2m_min: data.weather.map(w => parseInt(w.mintempC)),
                    sunrise: data.weather.map(w => w.astronomy[0].sunrise),
                    sunset: data.weather.map(w => w.astronomy[0].sunset),
                    uv_index_max: data.weather.map(() => 5),
                    precipitation_sum: data.weather.map(w => parseFloat(w.totalSnow_cm) || 0),
                    wind_speed_10m_max: data.weather.map(w => parseInt(w.maxwindKmph))
                }
            };
        }
    } catch (error) {
        if (error.name !== 'AbortError') console.log('❌ wttr.in:', error.message);
    }
    return null;
}

// === API 3: 7Timer ===
async function fetchFrom7Timer(lat, lon) {
    try {
        console.log('🔄 Пробуем 7Timer...');
        const url = `https://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=civil&output=json`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        
        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'Accept': 'application/json' }
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ 7Timer работает!');
            
            const now = new Date();
            const series = data.dataseries;
            
            const dailyData = [];
            for (let i = 0; i < Math.min(series.length, 56); i += 8) {
                const daySlice = series.slice(i, i + 8);
                if (daySlice.length === 0) break;
                
                const temps = daySlice.map(h => h.temp2m);
                const maxTemp = Math.max(...temps);
                const minTemp = Math.min(...temps);
                
                const noonPoint = daySlice[Math.min(4, daySlice.length - 1)];
                
                const date = new Date(now.getTime() + (i / 8) * 86400000);
                const dateStr = date.toISOString().split('T')[0];
                
                dailyData.push({
                    date: dateStr,
                    maxTemp: maxTemp,
                    minTemp: minTemp,
                    code: noonPoint.weather,
                    wind: Math.max(...daySlice.map(h => h.wind10m?.speed || 0))
                });
            }
            
            const hourlyData = series.slice(0, 24).map((h, i) => {
                const time = new Date(now.getTime() + i * 3 * 3600000);
                return {
                    time: time.toISOString(),
                    temp: h.temp2m,
                    code: h.weather
                };
            });
            
            return {
                current: {
                    temperature_2m: series[0].temp2m,
                    relative_humidity_2m: series[0].rh2m,
                    apparent_temperature: series[0].temp2m,
                    wind_speed_10m: series[0].wind10m?.speed || 0,
                    weather_code: convert7TimerCode(series[0].weather),
                    pressure_msl: 1013
                },
                hourly: {
                    time: hourlyData.map(h => h.time),
                    temperature_2m: hourlyData.map(h => h.temp),
                    weather_code: hourlyData.map(h => convert7TimerCode(h.code))
                },
                daily: {
                    time: dailyData.map(d => d.date),
                    weather_code: dailyData.map(d => convert7TimerCode(d.code)),
                    temperature_2m_max: dailyData.map(d => d.maxTemp),
                    temperature_2m_min: dailyData.map(d => d.minTemp),
                    sunrise: dailyData.map(() => '06:00'),
                    sunset: dailyData.map(() => '20:00'),
                    uv_index_max: dailyData.map(() => 5),
                    precipitation_sum: dailyData.map(() => 0),
                    wind_speed_10m_max: dailyData.map(d => d.wind)
                }
            };
        }
    } catch (error) {
        if (error.name !== 'AbortError') console.log('❌ 7Timer:', error.message);
    }
    return null;
}

// === ГЛАВНАЯ ФУНКЦИЯ ===
async function fetchWeatherData(lat, lon) {
    console.log('🌤️ Запрос погоды для координат:', lat, lon);
    const startTime = Date.now();
    
    const openMeteoPromise = fetchFromOpenMeteo(lat, lon);
    
    const delayedWttr = new Promise(resolve => 
        setTimeout(() => resolve(fetchFromWttr(lat, lon)), 500)
    );
    const delayedTimer = new Promise(resolve => 
        setTimeout(() => resolve(fetchFrom7Timer(lat, lon)), 500)
    );
    
    try {
        const result = await Promise.any([
            openMeteoPromise.then(d => { 
                if (!d) throw new Error('no data'); 
                console.log(`⚡ Open-Meteo ответил за ${Date.now() - startTime}мс`);
                return d; 
            }),
            delayedWttr.then(d => { 
                if (!d) throw new Error('no data'); 
                console.log(`⚡ wttr.in ответил за ${Date.now() - startTime}мс`);
                return d; 
            }),
            delayedTimer.then(d => { 
                if (!d) throw new Error('no data'); 
                console.log(`⚡ 7Timer ответил за ${Date.now() - startTime}мс`);
                return d; 
            })
        ]);
        
        if (!result || !result.current) {
            throw new Error('Получены невалидные данные');
        }
        
        console.log('✅ Температура:', result.current.temperature_2m);
        return result;
    } catch (error) {
        console.error('❌ Все API недоступны');
        
        const cached = await storage.get(['weather_cache', 'weather_cache_time']);
        if (cached.weather_cache && cached.weather_cache_time) {
            const cacheAge = Date.now() - cached.weather_cache_time;
            if (cacheAge < 2 * 60 * 60 * 1000) {
                console.log('⚡ Используем кэш');
                return cached.weather_cache;
            }
        }
        
        throw new Error('Все сервисы погоды недоступны');
    }
}

async function fetchAirQuality(lat, lon) {
    try {
        const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=european_aqi,us_aqi`;
        const response = await fetch(url);
        if (response.ok) return await response.json();
    } catch (error) {
        console.log('Air quality fetch failed:', error);
    }
    return null;
}

async function httpRequest(url) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.timeout = 8000;
        
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    resolve(JSON.parse(xhr.responseText));
                } catch (e) {
                    reject(new Error('Ошибка парсинга'));
                }
            } else {
                reject(new Error(`HTTP ${xhr.status}`));
            }
        };
        
        xhr.onerror = () => reject(new Error('Network error'));
        xhr.ontimeout = () => reject(new Error('Timeout'));
        xhr.send();
    });
}

// === УТИЛИТЫ ===
function getMoonPhase(date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    let c = 0, e = 0, jd = 0;
    
    if (month < 3) {
        c = year - 1;
        e = month + 12;
    } else {
        c = year;
        e = month;
    }
    
    jd = (365.25 * (c + 4716)) + (30.6001 * (e + 1)) + day - 1524.5;
    const daysSinceNew = jd - 2451549.5;
    const newMoons = daysSinceNew / 29.530588853;
    const phase = (newMoons - Math.floor(newMoons)) * 29.530588853;
    
    if (phase < 1.84566) return { icon: '🌑', name: 'Новолуние' };
    if (phase < 5.53699) return { icon: '🌒', name: 'Растущий серп' };
    if (phase < 9.22831) return { icon: '🌓', name: 'Первая четверть' };
    if (phase < 12.91963) return { icon: '🌔', name: 'Растущая луна' };
    if (phase < 16.61096) return { icon: '🌕', name: 'Полнолуние' };
    if (phase < 20.30228) return { icon: '🌖', name: 'Убывающая луна' };
    if (phase < 23.99361) return { icon: '🌗', name: 'Последняя четверть' };
    if (phase < 27.68493) return { icon: '🌘', name: 'Убывающий серп' };
    return { icon: '🌑', name: 'Новолуние' };
}

function formatTime(isoString) {
    if (!isoString) return '--:--';
    
    if (typeof isoString === 'string' && isoString.includes(':') && !isoString.includes('T')) {
        return isoString;
    }
    
    try {
        const date = new Date(isoString);
        if (isNaN(date.getTime())) return '--:--';
        return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
        return '--:--';
    }
}

function formatDay(isoString, index) {
    if (index === 0) return 'Сегодня';
    if (index === 1) return 'Завтра';
    const date = new Date(isoString);
    return date.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' });
}

// === АВТОМАТИЧЕСКИЙ ФОН ПО ТЕМПЕРАТУРЕ ===
function applyTemperatureBackground(tempCelsius, isFullBackground = false) {
    let bgClass = '';
    if (tempCelsius < -10) {
        bgClass = 'temp-bg-freezing';
    } else if (tempCelsius < 10) {
        bgClass = 'temp-bg-cold';
    } else if (tempCelsius < 20) {
        bgClass = 'temp-bg-cool';
    } else if (tempCelsius < 28) {
        bgClass = 'temp-bg-warm';
    } else {
        bgClass = 'temp-bg-hot';
    }
    
    if (isFullBackground) {
        document.body.classList.remove('temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot');
        document.body.classList.add(bgClass);
    } else {
        const currentWeatherEl = document.getElementById('current-weather');
        if (currentWeatherEl) {
            currentWeatherEl.classList.remove('temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot');
            currentWeatherEl.classList.add(bgClass);
        }
    }
}

// === ГЛАВНЫЙ КОД ===
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🌤️ Extension loaded (v9.0)');
    
    const cityInput = document.getElementById('city-input');
    const searchBtn = document.getElementById('search-btn');
    const refreshBtn = document.getElementById('refresh-btn');
    const geoBtn = document.getElementById('geo-btn');
    const settingsBtn = document.getElementById('settings-btn');
    const clearSearchBtn = document.getElementById('clear-search');
    const currentWeatherEl = document.getElementById('current-weather');
    const detailsGridEl = document.getElementById('details-grid');
    const suggestionsEl = document.getElementById('suggestions');
    const settingsModal = document.getElementById('settings-modal');
    const closeSettingsBtn = document.getElementById('close-settings');
    const saveSettingsBtn = document.getElementById('save-settings');
    const extraDataSection = document.getElementById('extra-data');
    const weatherAnimation = document.getElementById('weather-animation');
    
    let weatherChart = null;
    let lastWeatherData = null;
    let currentRequestId = 0;
    let autoUpdateTimer = null;
    let lastCityForUpdate = null;

    const settingsResult = await storage.get([
        'show_humidity', 'show_wind', 'show_pressure', 'show_feels_like',
        'unit_temp', 'unit_wind', 'unit_pressure',
        'auto_background', 'notifications_enabled',
        'last_notification_date', 'theme', 'color_scheme'
    ]);
    
    let settings = {
        show_humidity: settingsResult.show_humidity !== false,
        show_wind: settingsResult.show_wind !== false,
        show_pressure: settingsResult.show_pressure !== false,
        show_feels_like: settingsResult.show_feels_like !== false,
        unit_temp: settingsResult.unit_temp || 'c',
        unit_wind: settingsResult.unit_wind || 'ms',
        unit_pressure: settingsResult.unit_pressure || 'mmhg',
        auto_background: settingsResult.auto_background || false,
        background_mode: settingsResult.background_mode || 'section',
        notifications_enabled: settingsResult.notifications_enabled || false,
        last_notification_date: settingsResult.last_notification_date || 0
    };

    const themes = ['light', 'dark'];
    const colorSchemes = ['default', 'sunset', 'forest', 'midnight', 'ocean', 'lavender'];
    let currentTheme = settingsResult.theme || 'light';
    let currentColorScheme = settingsResult.color_scheme || 'default';

    if (settings.auto_background) {
        const cached = await storage.get(['weather_cache']);
        if (cached.weather_cache) {
            applyTemperatureBackground(cached.weather_cache.current.temperature_2m);
        }
    }

    function updateThemeClasses() {
        const bgClasses = ['temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot'];
        const currentBgClasses = bgClasses.filter(cls => document.body.classList.contains(cls));
        
        document.body.className = '';
        document.body.classList.add(`theme-${currentTheme}`, `color-scheme-${currentColorScheme}`);
        currentBgClasses.forEach(cls => document.body.classList.add(cls));
    }

    function updateThemeButtonsVisibility() {
        const themeBtn = document.getElementById('theme-toggle');
        const colorBtn = document.getElementById('color-scheme-toggle');
        
        if (settings.auto_background && settings.background_mode === 'full') {
            if (themeBtn) themeBtn.classList.add('hidden');
            if (colorBtn) colorBtn.classList.add('hidden');
        } else {
            if (themeBtn) themeBtn.classList.remove('hidden');
            if (colorBtn) colorBtn.classList.remove('hidden');
        }
    }

    updateThemeClasses();
    updateThemeButtonsVisibility();

    if (document.getElementById('theme-toggle')) {
        document.getElementById('theme-toggle').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            currentTheme = currentTheme === 'light' ? 'dark' : 'light';
            updateThemeClasses();
            storage.set({ theme: currentTheme });
            showNotification(`Тема: ${currentTheme === 'light' ? 'Светлая ☀️' : 'Тёмная 🌙'}`);
        });
    }

    if (document.getElementById('color-scheme-toggle')) {
        document.getElementById('color-scheme-toggle').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const currentIndex = colorSchemes.indexOf(currentColorScheme);
            currentColorScheme = colorSchemes[(currentIndex + 1) % colorSchemes.length];
            updateThemeClasses();
            storage.set({ color_scheme: currentColorScheme });
            
            const schemeNames = {
                'default': 'Стандартная',
                'sunset': 'Закат 🌅',
                'forest': 'Лес 🌲',
                'midnight': 'Полночь 🌌',
                'ocean': 'Океан 🌊',
                'lavender': 'Лаванда 💜'
            };
            showNotification(`Схема: ${schemeNames[currentColorScheme]}`);
        });
    }

    function showNotification(message) {
        const toast = document.createElement('div');
        toast.className = 'notification-toast';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2500);
    }

    cityInput.addEventListener('focus', () => showSuggestions(''));
    cityInput.addEventListener('input', () => showSuggestions(cityInput.value.trim()));
    cityInput.addEventListener('blur', () => {
        setTimeout(() => suggestionsEl.classList.remove('active'), 200);
    });
    
    async function showSuggestions(query) {
        const requestId = ++currentRequestId;
        // eslint-disable-next-line no-unsanitized/property
        suggestionsEl.innerHTML = '';
        
        let items = [];
        
        if (query.length === 0) {
            items = POPULAR_CITIES.slice(0, 5).map(c => ({ ...c, popular: true }));
            renderSuggestions(items, requestId);
        } else if (query.length >= 1) {
            const localMatches = POPULAR_CITIES
                .filter(c => c.name.toLowerCase().startsWith(query.toLowerCase()))
                .slice(0, 3)
                .map(c => ({ ...c, popular: false }));
            
            renderSuggestions(localMatches, requestId);
            
            try {
                const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=ru`;
                const geoData = await httpRequest(geoUrl);
                
                if (requestId !== currentRequestId) return;
                
                if (geoData.results) {
                    const apiMatches = geoData.results
                        .filter(r => !localMatches.some(l => l.name === r.name))
                        .slice(0, 8)
                        .map(r => ({
                            name: r.name,
                            country: r.country || '',
                            admin1: r.admin1 || '',
                            lat: r.latitude,
                            lon: r.longitude,
                            popular: false
                        }));
                    
                    const allItems = [...localMatches, ...apiMatches].slice(0, 8);
                    renderSuggestions(allItems, requestId);
                }
            } catch (error) {
                console.log('API error:', error);
            }
        }
    }
    
    function renderSuggestions(items, requestId) {
        if (requestId !== currentRequestId) return;
        // eslint-disable-next-line no-unsanitized/property
        suggestionsEl.innerHTML = '';
        
        if (items.length === 0) {
            suggestionsEl.classList.remove('active');
            return;
        }
        
        items.forEach(item => {
            const div = document.createElement('div');
            div.className = 'suggestion-item' + (item.popular ? ' popular' : '');
            
            const citySpan = document.createElement('span');
            citySpan.className = 'city-name';
            citySpan.textContent = item.name + (item.admin1 ? `, ${item.admin1}` : '');
            
            const countrySpan = document.createElement('span');
            countrySpan.className = 'country';
            countrySpan.textContent = item.country;
            
            div.appendChild(citySpan);
            div.appendChild(countrySpan);
            
            div.addEventListener('mousedown', (e) => {
                e.preventDefault();
                suggestionsEl.classList.remove('active');
                cityInput.value = '';
                loadWeatherDirect(item.name, item.lat, item.lon);
            });
            suggestionsEl.appendChild(div);
        });
        
        suggestionsEl.classList.add('active');
    }

    searchBtn.addEventListener('click', () => {
        const city = cityInput.value.trim();
        if (city) {
            suggestionsEl.classList.remove('active');
            cityInput.value = '';
            loadWeather(city);
        }
    });

    cityInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            suggestionsEl.classList.remove('active');
            searchBtn.click();
        }
    });

    refreshBtn.addEventListener('click', () => {
        console.log('🔄 Ручное обновление...');
        showNotification('🔄 Обновляем погоду...');
        
        if (lastWeatherData && lastWeatherData._place) {
            loadWeatherDirect(
                lastWeatherData.cityName,
                lastWeatherData._place.lat,
                lastWeatherData._place.lon
            );
        } else {
            const city = cityInput.value.trim();
            if (city) {
                loadWeather(city);
            } else {
                showNotification('Выберите город для обновления');
            }
        }
    });

    geoBtn.addEventListener('click', () => detectLocation());
    settingsBtn.addEventListener('click', () => openSettingsModal());

    clearSearchBtn.addEventListener('click', () => {
        cityInput.value = '';
        suggestionsEl.classList.remove('active');
        cityInput.focus();
    });

    function openSettingsModal() {
        document.getElementById('show-humidity').checked = settings.show_humidity;
        document.getElementById('show-wind').checked = settings.show_wind;
        document.getElementById('show-pressure').checked = settings.show_pressure;
        document.getElementById('show-feels-like').checked = settings.show_feels_like;
        document.getElementById('unit-temp').value = settings.unit_temp;
        document.getElementById('unit-wind').value = settings.unit_wind;
        document.getElementById('unit-pressure').value = settings.unit_pressure;
        document.getElementById('auto-background').checked = settings.auto_background;
        
        const bgModeSetting = document.getElementById('background-mode-setting');
        if (settings.auto_background) {
            bgModeSetting.style.display = 'flex';
            document.getElementById('background-mode').value = settings.background_mode || 'section';
        } else {
            bgModeSetting.style.display = 'none';
        }
        
        settingsModal.classList.add('active');
    }

    closeSettingsBtn.addEventListener('click', () => settingsModal.classList.remove('active'));
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) settingsModal.classList.remove('active');
    });

    document.getElementById('auto-background').addEventListener('change', (e) => {
        const bgModeSetting = document.getElementById('background-mode-setting');
        bgModeSetting.style.display = e.target.checked ? 'flex' : 'none';
    });

    saveSettingsBtn.addEventListener('click', async () => {
        settings = {
            ...settings,
            show_humidity: document.getElementById('show-humidity').checked,
            show_wind: document.getElementById('show-wind').checked,
            show_pressure: document.getElementById('show-pressure').checked,
            show_feels_like: document.getElementById('show-feels-like').checked,
            unit_temp: document.getElementById('unit-temp').value,
            unit_wind: document.getElementById('unit-wind').value,
            unit_pressure: document.getElementById('unit-pressure').value,
            auto_background: document.getElementById('auto-background').checked,
            background_mode: document.getElementById('background-mode').value
        };
        
        await storage.set(settings);
        settingsModal.classList.remove('active');
        
        updateThemeButtonsVisibility();
        
        if (settings.auto_background && lastWeatherData) {
            const isFull = settings.background_mode === 'full';
            applyTemperatureBackground(lastWeatherData.current.temperature_2m, isFull);
            
            if (!isFull) {
                document.body.classList.remove('temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot');
            }
        } else if (!settings.auto_background) {
            document.body.classList.remove('temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot');
            const currentWeatherEl = document.getElementById('current-weather');
            if (currentWeatherEl) {
                currentWeatherEl.classList.remove('temp-bg-freezing', 'temp-bg-cold', 'temp-bg-cool', 'temp-bg-warm', 'temp-bg-hot');
            }
        }
        
        if (lastWeatherData) rerenderWeather();
        showNotification('Настройки сохранены 💾');
    });

    function showLoading(message) {
        // eslint-disable-next-line no-unsanitized/property
        currentWeatherEl.innerHTML = '';
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'loading';
        loadingDiv.style.cssText = 'text-align: center; padding: 20px;';
        loadingDiv.textContent = message;
        currentWeatherEl.appendChild(loadingDiv);
    }

    async function loadWeather(city) {
        console.log('Loading weather for:', city);
        
        showLoading('🔄 Загрузка...');
        extraDataSection.classList.add('hidden');
        
        try {
            const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=ru`;
            const geoData = await httpRequest(geoUrl);
            
            if (!geoData.results || geoData.results.length === 0) {
                throw new Error('Город не найден');
            }
            
            const place = geoData.results[0];
            const cityName = `${place.name}${place.admin1 ? ', ' + place.admin1 : ''}, ${place.country}`;
            
            await storage.remove(['weather_cache', 'weather_cache_time']);
            
            await loadWeatherDirect(cityName, place.latitude, place.longitude, city, place);
            
        } catch (error) {
            console.error('Error:', error);
            showError('Ошибка: ' + error.message);
        }
    }

    async function loadWeatherDirect(cityName, lat, lon, cityKey = null, place = null) {
        try {
            console.log('🌤️ Загрузка для:', cityName, 'Координаты:', lat, lon);
            console.log('🔍 cityKey:', cityKey);
            
            showLoading('🔄 Загрузка...');
            
            const weatherData = await fetchWeatherData(lat, lon);
            
            console.log('✅ Получены данные:', weatherData);
            console.log('️ Температура:', weatherData.current.temperature_2m);
            console.log('📅 Прогноз на сегодня:', weatherData.daily.temperature_2m_max[0], weatherData.daily.temperature_2m_min[0]);
            
            if (!weatherData || !weatherData.current || !weatherData.daily) {
                throw new Error('Неверный формат данных от сервера');
            }
            
            fetchAirQuality(lat, lon).then(airData => {
                if (airData && lastWeatherData) {
                    lastWeatherData.airQuality = airData;
                    renderExtraData(lastWeatherData.current, lastWeatherData.daily, airData);
                }
            }).catch(() => {});
            
            lastWeatherData = {
                current: weatherData.current,
                hourly: weatherData.hourly,
                daily: weatherData.daily,
                airQuality: null,
                cityName: cityName,
                _place: place || { lat, lon }
            };
            
            rerenderWeather();
            updateBadge(convertTemp(weatherData.current.temperature_2m, settings.unit_temp));
            
            if (settings.auto_background) {
                const isFull = settings.background_mode === 'full';
                applyTemperatureBackground(weatherData.current.temperature_2m, isFull);
            }
            
            checkNotifications(weatherData, cityName);
            
            const saveKey = cityKey || cityName.split(',')[0];
            console.log('💾 Сохраняем в кэш для города:', saveKey);
            
            await storage.set({
                weather_cache: lastWeatherData,
                weather_cache_time: Date.now(),
                weather_city: saveKey,
                is_geolocation: place ? false : false,
                geo_lat: lat,
                geo_lon: lon
            });
            
            setupAutoUpdate(cityName, lat, lon, cityKey, place);
            
            console.log('✅ Данные загружены и сохранены для:', cityName);
            
        } catch (error) {
            console.error('❌ Error:', error);
            showError('Ошибка: ' + error.message);
        }
    }

    function setupAutoUpdate(cityName, lat, lon, cityKey, place) {
        if (autoUpdateTimer) {
            clearInterval(autoUpdateTimer);
        }
        
        lastCityForUpdate = { cityName, lat, lon, cityKey, place };
        
        console.log('⏰ Запущено автообновление для:', cityName, 'координаты:', lat, lon);
        
        autoUpdateTimer = setInterval(async () => {
            console.log('⏰ Автообновление погоды...');
            try {
                const weatherData = await fetchWeatherData(lat, lon);
                
                lastWeatherData = {
                    current: weatherData.current,
                    hourly: weatherData.hourly,
                    daily: weatherData.daily,
                    airQuality: lastWeatherData?.airQuality || null,
                    cityName: cityName,
                    _place: place || { lat, lon }
                };
                
                rerenderWeather();
                updateBadge(convertTemp(weatherData.current.temperature_2m, settings.unit_temp));
                
                if (settings.auto_background) {
                    const isFull = settings.background_mode === 'full';
                    applyTemperatureBackground(weatherData.current.temperature_2m, isFull);
                }
                
                await storage.set({
                    weather_cache: lastWeatherData,
                    weather_cache_time: Date.now(),
                    weather_city: cityKey || cityName.split(',')[0]
                });
                
                console.log('✅ Автообновление завершено, температура:', weatherData.current.temperature_2m);
            } catch (error) {
                console.log('⚠️ Автообновление не удалось:', error.message);
            }
        }, AUTO_UPDATE_INTERVAL);
    }

    function checkNotifications(weatherData, cityName) {
        if (!settings.notifications_enabled) return;
        
        const today = new Date().toDateString();
        const lastNotif = new Date(settings.last_notification_date).toDateString();
        
        if (today === lastNotif) return;
        
        const temp = weatherData.current.temperature_2m;
        const code = weatherData.current.weather_code;
        
        let message = null;
        
        if (temp > 30) message = `🔥 В ${cityName} жара: ${Math.round(temp)}°C!`;
        else if (temp < -20) message = `❄️ В ${cityName} мороз: ${Math.round(temp)}°C!`;
        else if (code >= 51 && code <= 67) message = `🌧️ В ${cityName} дождь!`;
        else if (code >= 71 && code <= 77) message = `🌨️ В ${cityName} снег!`;
        else if (code >= 95) message = `⛈️ В ${cityName} гроза!`;
        
        if (message) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icons/icon128.png',
                title: 'Погода+',
                message: message
            });
            
            storage.set({ last_notification_date: Date.now() });
        }
    }

    function rerenderWeather() {
        if (!lastWeatherData) return;
        
        const { current, hourly, daily, airQuality, cityName } = lastWeatherData;
        
        renderCurrentWeather(current, cityName);
        renderWeeklyForecast(daily);
        renderChartFromHourly(hourly);
        renderDetails(current, settings);
        renderExtraData(current, daily, airQuality);
        updateWeatherAnimation(current.weather_code);
    }

    function detectLocation() {
        console.log('📍 Detecting location...');
        showLoading('📍 Определение...');
        extraDataSection.classList.add('hidden');
        
        if (!navigator.geolocation) {
            showError('Геолокация не поддерживается');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            async (pos) => {
                console.log('✅ Location:', pos.coords);
                showLoading('🔄 Загрузка...');
                
                let cityName = 'Моё местоположение';
                
                try {
                    const geoUrl = `https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json&accept-language=ru&zoom=10`;
                    const geoData = await httpRequest(geoUrl);
                    
                    if (geoData && geoData.address) {
                        const addr = geoData.address;
                        const city = addr.city || addr.town || addr.village || '';
                        const region = addr.state || addr.region || '';
                        const country = addr.country || '';
                        
                        if (city) {
                            cityName = city + (region ? `, ${region}` : '') + (country ? `, ${country}` : '');
                        }
                    }
                } catch (error) {
                    console.error('Geocoding error:', error);
                }
                
                cityInput.value = '';
                
                try {
                    await loadWeatherDirect(cityName, pos.coords.latitude, pos.coords.longitude, null, {
                        lat: pos.coords.latitude,
                        lon: pos.coords.longitude
                    });
                    
                    await storage.set({
                        is_geolocation: true,
                        geo_lat: pos.coords.latitude,
                        geo_lon: pos.coords.longitude
                    });
                } catch (error) {
                    showError('Ошибка: ' + error.message);
                }
            },
            (err) => {
                console.error('❌ Geolocation error:', err);
                let errorMsg = 'Не удалось определить местоположение.\n\n';
                
                if (err.code === 1) {
                    errorMsg += '❌ Доступ запрещён.\nРазрешите в настройках Firefox';
                } else if (err.code === 2) {
                    errorMsg += '❌ Геолокация недоступна';
                } else {
                    errorMsg += '⏱️ Превышено время';
                }
                
                showError(errorMsg);
            },
            { 
                enableHighAccuracy: false,
                timeout: 10000,
                maximumAge: 60000
            }
        );
    }

    function renderCurrentWeather(data, cityName) {
        const icon = getWeatherIcon(data.weather_code);
        const updateTime = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
        const tempUnit = getTempUnitLabel(settings.unit_temp);
        
        // eslint-disable-next-line no-unsanitized/property
        currentWeatherEl.innerHTML = '';
        
        const cityDiv = document.createElement('div');
        cityDiv.className = 'city-name';
        cityDiv.textContent = cityName;
        
        const tempDiv = document.createElement('div');
        tempDiv.className = 'temp';
        tempDiv.textContent = `${convertTemp(data.temperature_2m, settings.unit_temp)}${tempUnit}`;
        
        const descDiv = document.createElement('div');
        descDiv.className = 'description';
        // eslint-disable-next-line no-unsanitized/property
        descDiv.innerHTML = `<span style="font-size: 24px; margin-right: 8px;">${icon}</span>${getWeatherDescription(data.weather_code)}`;
        
        const feelsDiv = document.createElement('div');
        feelsDiv.className = 'feels-like';
        feelsDiv.textContent = `Ощущается как ${convertTemp(data.apparent_temperature, settings.unit_temp)}${tempUnit}`;
        
        const updateDiv = document.createElement('div');
        updateDiv.style.cssText = 'text-align: center; font-size: 11px; opacity: 0.5; margin-top: 10px;';
        updateDiv.textContent = `Обновлено: ${updateTime}`;
        
        currentWeatherEl.appendChild(cityDiv);
        currentWeatherEl.appendChild(tempDiv);
        currentWeatherEl.appendChild(descDiv);
        currentWeatherEl.appendChild(feelsDiv);
        currentWeatherEl.appendChild(updateDiv);
        
        if (settings.auto_background && settings.background_mode === 'section') {
            applyTemperatureBackground(data.temperature_2m, false);
        }
    }

    function renderWeeklyForecast(daily) {
        const container = document.getElementById('weekly-forecast-container');
        // eslint-disable-next-line no-unsanitized/property
        container.innerHTML = '';
        
        if (!daily || !daily.time) {
            const emptyDiv = document.createElement('div');
            emptyDiv.style.cssText = 'opacity: 0.6; text-align: center;';
            emptyDiv.textContent = 'Нет данных';
            container.appendChild(emptyDiv);
            return;
        }
        
        daily.time.forEach((date, index) => {
            const maxTemp = convertTemp(daily.temperature_2m_max[index], settings.unit_temp);
            const minTemp = convertTemp(daily.temperature_2m_min[index], settings.unit_temp);
            const icon = getWeatherIcon(daily.weather_code[index]);
            const desc = getWeatherDescription(daily.weather_code[index]);
            const dayName = formatDay(date, index);
            const tempUnit = getTempUnitLabel(settings.unit_temp);
            
            const dayDiv = document.createElement('div');
            dayDiv.className = 'weekly-day';
            
            const nameDiv = document.createElement('div');
            nameDiv.className = 'day-name';
            nameDiv.textContent = dayName;
            
            const iconDiv = document.createElement('div');
            iconDiv.className = 'day-icon';
            iconDiv.textContent = icon;
            iconDiv.style.fontSize = '28px';
            
            const descDiv = document.createElement('div');
            descDiv.className = 'day-desc';
            descDiv.textContent = desc;
            
            const tempDiv = document.createElement('div');
            tempDiv.className = 'day-temp';
            
            const maxSpan = document.createElement('span');
            maxSpan.className = 'temp-max';
            maxSpan.textContent = `${maxTemp}${tempUnit}`;
            
            const minSpan = document.createElement('span');
            minSpan.className = 'temp-min';
            minSpan.textContent = `${minTemp}${tempUnit}`;
            
            tempDiv.appendChild(maxSpan);
            tempDiv.appendChild(minSpan);
            
            dayDiv.appendChild(nameDiv);
            dayDiv.appendChild(iconDiv);
            dayDiv.appendChild(descDiv);
            dayDiv.appendChild(tempDiv);
            
            container.appendChild(dayDiv);
        });
    }

    function renderChartFromHourly(hourly) {
        if (!hourly || !hourly.time) return;
        const forecast = hourly.time.slice(0, 24).map((time, index) => ({
            temp: convertTemp(hourly.temperature_2m[index], settings.unit_temp),
            time: time.split('T')[1].substring(0, 2) + ':00'
        }));
        
        renderChart(forecast);
    }

    function renderDetails(data, settings) {
        const details = [];
        
        if (settings.show_humidity) {
            const humidity = data.relative_humidity_2m;
            const humidityValue = typeof humidity === 'string' ? humidity.replace('%', '').trim() : humidity;
            details.push({ label: 'Влажность', value: `${humidityValue}%` });
        }
        if (settings.show_wind) {
            details.push({ 
                label: 'Ветер', 
                value: `${convertWind(data.wind_speed_10m, settings.unit_wind)} ${getWindUnitLabel(settings.unit_wind)}` 
            });
        }
        if (settings.show_pressure) {
            details.push({ 
                label: 'Давление', 
                value: `${convertPressure(data.pressure_msl, settings.unit_pressure)} ${getPressureUnitLabel(settings.unit_pressure)}` 
            });
        }
        if (settings.show_feels_like) {
            details.push({ 
                label: 'Ощущается', 
                value: `${convertTemp(data.apparent_temperature, settings.unit_temp)}${getTempUnitLabel(settings.unit_temp)}` 
            });
        }

        // eslint-disable-next-line no-unsanitized/property
        detailsGridEl.innerHTML = '';
        
        details.forEach(d => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'detail-item';
            
            const labelDiv = document.createElement('div');
            labelDiv.className = 'label';
            labelDiv.textContent = d.label;
            
            const valueDiv = document.createElement('div');
            valueDiv.className = 'value';
            valueDiv.textContent = d.value;
            
            itemDiv.appendChild(labelDiv);
            itemDiv.appendChild(valueDiv);
            detailsGridEl.appendChild(itemDiv);
        });
    }

    function renderExtraData(current, daily, airQuality) {
        extraDataSection.classList.remove('hidden');
        
        const sunrise = daily.sunrise && daily.sunrise[0] ? formatTime(daily.sunrise[0]) : '--:--';
        const sunset = daily.sunset && daily.sunset[0] ? formatTime(daily.sunset[0]) : '--:--';
        
        const uvIndex = daily.uv_index_max ? Math.round(daily.uv_index_max[0]) : '--';
        const precipitation = daily.precipitation_sum ? `${daily.precipitation_sum[0]} мм` : '--';
        const visibility = current.weather_code >= 45 && current.weather_code <= 48 ? '< 1 км' : '> 10 км';
        
        let aqText = '--';
        if (airQuality && airQuality.current) {
            const aqi = airQuality.current.european_aqi;
            if (aqi <= 20) aqText = 'Отличное';
            else if (aqi <= 40) aqText = 'Хорошее';
            else if (aqi <= 60) aqText = 'Умеренное';
            else if (aqi <= 80) aqText = 'Плохое';
            else aqText = 'Очень плохое';
        }
        
        const moon = getMoonPhase(new Date());
        
        document.getElementById('sunrise').textContent = sunrise;
        document.getElementById('sunset').textContent = sunset;
        document.getElementById('uv-index').textContent = uvIndex;
        document.getElementById('visibility').textContent = visibility;
        document.getElementById('precipitation').textContent = precipitation;
        document.getElementById('air-quality').textContent = aqText;
        document.getElementById('moon-phase').textContent = `${moon.icon} ${moon.name}`;
    }   

    function renderChart(forecastData) {
        const canvas = document.getElementById('weatherChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const labels = forecastData.map(item => item.time);
        const temps = forecastData.map(item => item.temp);
        const tempUnit = getTempUnitLabel(settings.unit_temp);

        if (weatherChart) weatherChart.destroy();

        weatherChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: `Температура (${tempUnit})`,
                    data: temps,
                    borderColor: '#fff',
                    backgroundColor: 'rgba(255, 255, 255, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { 
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${ctx.parsed.y}${tempUnit}`
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { color: 'rgba(255,255,255,0.7)', maxTicksLimit: 8 } },
                    y: { grid: { color: 'rgba(255,255,255,0.1)' }, ticks: { color: 'rgba(255,255,255,0.7)' } }
                }
            }
        });
    }

    function updateWeatherAnimation(code) {
        console.log('🎨 Обновление анимации для кода:', code);
        
        document.getElementById('rain-container').classList.remove('active');
        document.getElementById('snow-container').classList.remove('active');
        document.getElementById('sun-rays').classList.remove('active');
        document.getElementById('clouds-container').classList.remove('active');
        document.getElementById('lightning').classList.remove('active');
        document.getElementById('fog-container').classList.remove('active');
        
        // eslint-disable-next-line no-unsanitized/property
        document.getElementById('rain-container').innerHTML = '';
        // eslint-disable-next-line no-unsanitized/property
        document.getElementById('snow-container').innerHTML = '';
        // eslint-disable-next-line no-unsanitized/property
        document.getElementById('sun-rays').innerHTML = '';
        // eslint-disable-next-line no-unsanitized/property
        document.getElementById('clouds-container').innerHTML = '';
        // eslint-disable-next-line no-unsanitized/property
        document.getElementById('fog-container').innerHTML = '';
        
        if (code === 0 || code === 1) {
            createSunEffect();
        } else if (code === 2 || code === 3) {
            createCloudsEffect();
        } else if (code >= 45 && code <= 48) {
            createFogEffect();
        } else if (code >= 51 && code <= 67) {
            createRainEffect(code >= 63 ? 'heavy' : 'light');
        } else if (code >= 71 && code <= 77) {
            createSnowEffect(code >= 75 ? 'heavy' : 'light');
        } else if (code >= 80 && code <= 82) {
            createRainEffect('heavy');
        } else if (code >= 85 && code <= 86) {
            createSnowEffect('heavy');
        } else if (code >= 95) {
            createRainEffect('heavy');
            createLightningEffect();
        }
    }

    function createSunEffect() {
        const sunContainer = document.getElementById('sun-rays');
        sunContainer.classList.add('active');
        
        const core = document.createElement('div');
        core.className = 'sun-core';
        sunContainer.appendChild(core);
        
        for (let i = 0; i < 8; i++) {
            const ray = document.createElement('div');
            ray.className = 'sun-ray';
            ray.style.transform = `translate(-50%, -50%) rotate(${i * 45}deg)`;
            sunContainer.appendChild(ray);
        }
    }

    function createCloudsEffect() {
        const cloudsContainer = document.getElementById('clouds-container');
        cloudsContainer.classList.add('active');
        
        const cloudCount = 3 + Math.floor(Math.random() * 3);
        
        for (let i = 0; i < cloudCount; i++) {
            const cloud = document.createElement('div');
            cloud.className = 'cloud';
            
            const width = 80 + Math.random() * 60;
            const height = 30 + Math.random() * 20;
            const top = 50 + Math.random() * 200;
            const duration = 20 + Math.random() * 20;
            const delay = Math.random() * 10;
            
            cloud.style.width = `${width}px`;
            cloud.style.height = `${height}px`;
            cloud.style.top = `${top}px`;
            cloud.style.animationDuration = `${duration}s`;
            cloud.style.animationDelay = `${delay}s`;
            
            cloudsContainer.appendChild(cloud);
        }
    }

    function createRainEffect(intensity) {
        const rainContainer = document.getElementById('rain-container');
        rainContainer.classList.add('active');
        
        const dropCount = intensity === 'heavy' ? 80 : 40;
        const duration = intensity === 'heavy' ? 0.5 : 0.8;
        
        for (let i = 0; i < dropCount; i++) {
            const drop = document.createElement('div');
            drop.className = 'raindrop';
            
            const left = Math.random() * 100;
            const animDuration = duration + Math.random() * 0.3;
            const delay = Math.random() * 2;
            
            drop.style.left = `${left}%`;
            drop.style.animationDuration = `${animDuration}s`;
            drop.style.animationDelay = `${delay}s`;
            
            rainContainer.appendChild(drop);
        }
    }

    function createSnowEffect(intensity) {
        const snowContainer = document.getElementById('snow-container');
        snowContainer.classList.add('active');
        
        const flakeCount = intensity === 'heavy' ? 60 : 30;
        
        for (let i = 0; i < flakeCount; i++) {
            const flake = document.createElement('div');
            flake.className = 'snowflake';
            
            const left = Math.random() * 100;
            const size = 3 + Math.random() * 5;
            const duration = 3 + Math.random() * 4;
            const delay = Math.random() * 5;
            
            flake.style.left = `${left}%`;
            flake.style.width = `${size}px`;
            flake.style.height = `${size}px`;
            flake.style.animationDuration = `${duration}s`;
            flake.style.animationDelay = `${delay}s`;
            
            snowContainer.appendChild(flake);
        }
    }

    function createLightningEffect() {
        document.getElementById('lightning').classList.add('active');
    }

    function createFogEffect() {
        const fogContainer = document.getElementById('fog-container');
        fogContainer.classList.add('active');
        
        for (let i = 0; i < 2; i++) {
            const layer = document.createElement('div');
            layer.className = 'fog-layer';
            layer.style.top = `${i * 30}%`;
            fogContainer.appendChild(layer);
        }
    }

    function getWeatherDescription(code) {
        const desc = {
            0: 'Ясно', 1: 'Преимущественно ясно', 2: 'Переменная облачность',
            3: 'Пасмурно', 45: 'Туман', 48: 'Изморозь',
            51: 'Лёгкая морось', 53: 'Морось', 55: 'Сильная морось',
            61: 'Небольшой дождь', 63: 'Дождь', 65: 'Сильный дождь',
            71: 'Небольшой снег', 73: 'Снег', 75: 'Сильный снег',
            80: 'Ливень', 81: 'Сильный ливень', 82: 'Очень сильный ливень',
            85: 'Снегопад', 86: 'Сильный снегопад',
            95: 'Гроза', 96: 'Гроза с градом', 99: 'Сильная гроза с градом'
        };
        return desc[code] || 'Неизвестно';
    }

    function getWeatherIcon(code) {
        const icons = {
            0: '☀️', 1: '🌤️', 2: '⛅', 3: '☁️',
            45: '🌫️', 48: '🌫️',
            51: '🌦️', 53: '🌦️', 55: '🌧️',
            61: '🌦️', 63: '🌧️', 65: '🌧️',
            71: '🌨️', 73: '🌨️', 75: '❄️', 77: '🌨️',
            80: '🌧️', 81: '⛈️', 82: '⛈️',
            85: '🌨️', 86: '❄️',
            95: '⛈️', 96: '⛈️', 99: '⛈️'
        };
        
        return icons[code] || '🌡️';
    }

    function updateBadge(temp) {
        let badgeText = `${Math.round(temp)}°`;
        if (badgeText.length > 4) badgeText = badgeText.substring(0, 4);
        chrome.action.setBadgeText({ text: badgeText });
        chrome.action.setBadgeBackgroundColor({ color: temp < 0 ? '#3498db' : temp < 20 ? '#2ecc71' : '#e74c3c' });
    }

    function showError(message) {
        // eslint-disable-next-line no-unsanitized/property
        currentWeatherEl.innerHTML = '';
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error';
        errorDiv.style.cssText = 'color: #fff; padding: 20px; text-align: center; font-size: 14px;';
        
        try {
            const parsed = JSON.parse(message);
            errorDiv.textContent = '❌ Ошибка сервера. Попробуйте позже.';
        } catch (e) {
            errorDiv.textContent = `❌ ${message}`;
        }
        
        currentWeatherEl.appendChild(errorDiv);
        // eslint-disable-next-line no-unsanitized/property
        detailsGridEl.innerHTML = '';
        chrome.action.setBadgeText({ text: '' });
    }

    const result = await storage.get(['weather_city', 'weather_cache', 'weather_cache_time', 'is_geolocation', 'geo_lat', 'geo_lon']);
    
    if (result.weather_cache && result.weather_cache_time) {
        console.log('⚡ Показываем из кэша (без обновления)');
        lastWeatherData = result.weather_cache;
        rerenderWeather();
        updateBadge(convertTemp(result.weather_cache.current.temperature_2m, settings.unit_temp));
        
        if (result.is_geolocation && result.geo_lat && result.geo_lon) {
            setupAutoUpdate('Моё местоположение', result.geo_lat, result.geo_lon, null, {
                lat: result.geo_lat,
                lon: result.geo_lon
            });
        } else if (result.weather_city) {
            const lat = result.weather_cache._place?.lat;
            const lon = result.weather_cache._place?.lon;
            if (lat && lon) {
                setupAutoUpdate(result.weather_city, lat, lon, result.weather_city, { lat, lon });
            }
        }
    } else {
        // eslint-disable-next-line no-unsanitized/property
        currentWeatherEl.innerHTML = '';
        const welcomeDiv = document.createElement('div');
        welcomeDiv.style.cssText = 'text-align: center; padding: 30px; color: rgba(255,255,255,0.9);';
        
        const iconDiv = document.createElement('div');
        iconDiv.style.cssText = 'font-size: 48px; margin-bottom: 15px;';
        iconDiv.textContent = '🌤️';
        
        const titleDiv = document.createElement('div');
        titleDiv.style.cssText = 'font-size: 16px; margin-bottom: 20px;';
        titleDiv.textContent = 'Добро пожаловать в Погода+!';
        
        const descDiv = document.createElement('div');
        descDiv.style.cssText = 'font-size: 13px; margin-bottom: 20px; opacity: 0.8;';
        descDiv.textContent = 'Начните вводить город или нажмите 📍';
        
        welcomeDiv.appendChild(iconDiv);
        welcomeDiv.appendChild(titleDiv);
        welcomeDiv.appendChild(descDiv);
        currentWeatherEl.appendChild(welcomeDiv);
    }
    
    updateThemeButtonsVisibility();
});