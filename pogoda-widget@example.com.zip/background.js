// === BACKGROUND SCRIPT v9.0 ===
const CACHE_DURATION = 5 * 60 * 1000; // 5 минут

const WEATHER_SERVERS = [
    'https://api-us.open-meteo.com/v1/forecast',
    'https://api.open-meteo.com/v1/forecast',
    'https://api-eu.open-meteo.com/v1/forecast'
];

chrome.runtime.onStartup.addListener(() => {
    console.log('🌤️ Browser started');
    loadWeatherInBackground();
});

chrome.runtime.onInstalled.addListener(() => {
    console.log('🌤️ Extension installed/updated');
    loadWeatherInBackground();
    chrome.alarms.create('updateWeather', { periodInMinutes: 5 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'updateWeather') {
        console.log('⏰ Auto-update weather (background)');
        updateBadgeFromCache();
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fetchWeather') {
        fetchWeatherByCity(request.city)
            .then(data => sendResponse({ success: true, data: data }))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }
    
    if (request.action === 'fetchByCoords') {
        fetchWeatherByCoords(request.lat, request.lon)
            .then(data => sendResponse({ success: true, data: data }))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }
});

async function loadWeatherInBackground() {
    try {
        const result = await chrome.storage.local.get([
            'weather_city', 'weather_cache', 'weather_cache_time', 
            'notifications_enabled', 'is_geolocation', 'geo_lat', 'geo_lon'
        ]);
        
        if (result.weather_cache && result.weather_cache_time) {
            const cacheAge = Date.now() - result.weather_cache_time;
            if (cacheAge < CACHE_DURATION) {
                console.log('⚡ Using cache in background');
                updateBadge(result.weather_cache.current.temperature_2m);
                return;
            }
        }
        
        // Загружаем погоду в фоне
        let data = null;
        let cityName = '';
        
        if (result.is_geolocation && result.geo_lat && result.geo_lon) {
            console.log('🔄 Loading weather for geolocation');
            data = await fetchWeatherByCoords(result.geo_lat, result.geo_lon);
            cityName = 'Моё местоположение';
        } else if (result.weather_city) {
            console.log('🔄 Loading weather for:', result.weather_city);
            data = await fetchWeatherByCity(result.weather_city);
            cityName = result.weather_city;
        }
        
        if (data) {
            await chrome.storage.local.set({
                weather_cache: data,
                weather_cache_time: Date.now()
            });
            updateBadge(data.current.temperature_2m);
            
            if (result.notifications_enabled) {
                checkNotifications(data, cityName);
            }
        }
    } catch (error) {
        console.error('Background error:', error);
    }
}

function checkNotifications(weatherData, cityName) {
    const temp = weatherData.current.temperature_2m;
    const code = weatherData.current.weather_code;
    
    let message = null;
    
    if (temp > 30) message = `🔥 В ${cityName} жара: ${Math.round(temp)}°C!`;
    else if (temp < -20) message = `❄️ В ${cityName} мороз: ${Math.round(temp)}°C!`;
    else if (code >= 51 && code <= 67) message = `🌧️ В ${cityName} дождь!`;
    else if (code >= 71 && code <= 77) message = `🌨️ В ${cityName} снег!`;
    else if (code >= 95) message = `⛈️ В ${cityName} гроза!`;
    
    if (message) {
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Погода+',
            message: message
        });
    }
}

async function fetchWeatherByCity(city) {
    try {
        const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=ru`;
        const geoRes = await fetch(geoUrl);
        const geoData = await geoRes.json();
        
        if (!geoData.results || geoData.results.length === 0) {
            throw new Error('Город не найден');
        }
        
        const place = geoData.results[0];
        const cityName = `${place.name}${place.admin1 ? ', ' + place.admin1 : ''}, ${place.country}`;
        
        const weatherData = await fetchWeatherData(place.latitude, place.longitude);
        weatherData.cityName = cityName;
        
        return weatherData;
        
    } catch (error) {
        console.error('Fetch weather error:', error);
        throw error;
    }
}

async function fetchWeatherByCoords(lat, lon) {
    try {
        const weatherData = await fetchWeatherData(lat, lon);
        weatherData.cityName = 'Моё местоположение';
        return weatherData;
    } catch (error) {
        console.error('Fetch coords error:', error);
        throw error;
    }
}

// === ЗАПРОСЫ ===

function convertWttrCode(code) {
    const codeMap = {
        '113': 0, '116': 1, '119': 2, '122': 3,
        '143': 45, '176': 61, '179': 71, '182': 65,
        '185': 65, '200': 95, '227': 71, '230': 75,
        '248': 45, '260': 45, '263': 51, '266': 51,
        '281': 55, '284': 55, '293': 61, '296': 61,
        '299': 63, '302': 63, '305': 65, '308': 65,
        '311': 65, '314': 65, '317': 65, '320': 71,
        '323': 71, '326': 71, '329': 73, '332': 73,
        '335': 75, '338': 75, '350': 65, '353': 61,
        '356': 63, '359': 65, '362': 65, '365': 65,
        '368': 71, '371': 73, '374': 65, '377': 65,
        '386': 95, '389': 95, '392': 71, '395': 75
    };
    return codeMap[code] || 0;
}

function convert7TimerCode(code) {
    const codeMap = {
        'clear': 0, 'pcloudy': 2, 'mcloudy': 3,
        'cloudy': 3, 'overscst': 3, 'rain': 63,
        'lightrain': 61, 'hrain': 65, 'tsrain': 95,
        'snow': 73, 'lsnow': 71, 'hsnow': 75,
        'fog': 45
    };
    return codeMap[code] || 0;
}

async function fetchFromOpenMeteo(lat, lon) {
    const SERVERS = [
        'https://api-us.open-meteo.com/v1/forecast',
        'https://api.open-meteo.com/v1/forecast',
        'https://api-eu.open-meteo.com/v1/forecast'
    ];

    const params = `latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,pressure_msl` +
        `&hourly=temperature_2m,weather_code` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,wind_speed_10m_max` +
        `&forecast_days=7&timezone=auto`;

    const controllers = SERVERS.map(() => new AbortController());
    
    const fetchPromises = SERVERS.map((server, index) => {
        return new Promise(async (resolve) => {
            const timeout = 4000;
            const timeoutId = setTimeout(() => {
                controllers[index].abort();
                resolve({ success: false, server });
            }, timeout);
            
            try {
                const url = `${server}?${params}`;
                const response = await fetch(url, { 
                    signal: controllers[index].signal,
                    headers: { 'Accept': 'application/json' }
                });
                
                clearTimeout(timeoutId);
                
                if (response.ok) {
                    const data = await response.json();
                    console.log('✅ BG Open-Meteo:', server);
                    controllers.forEach((ctrl, i) => { if (i !== index) ctrl.abort(); });
                    resolve({ success: true, data, server });
                    return;
                }
                resolve({ success: false, server });
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name !== 'AbortError') console.log('❌ BG Open-Meteo:', server);
                resolve({ success: false, server });
            }
        });
    });

    const results = await Promise.all(fetchPromises);
    const success = results.find(r => r.success);
    return success ? success.data : null;
}

async function fetchFromWttr(lat, lon) {
    try {
        console.log('🔄 BG: wttr.in...');
        const url = `https://wttr.in/${lat},${lon}?format=j1&lang=ru`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        
        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'Accept': 'application/json' }
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ BG: wttr.in работает!');
            
            const current = data.current_condition[0];
            const weather = data.weather[0];
            
            return {
                current: {
                    temperature_2m: parseFloat(current.temp_C),
                    relative_humidity_2m: parseInt(current.humidity),
                    apparent_temperature: parseFloat(current.FeelsLikeC),
                    wind_speed_10m: parseFloat(current.windspeedKmph),
                    weather_code: convertWttrCode(current.weatherCode),
                    pressure_msl: parseInt(current.pressure)
                },
                hourly: {
                    time: weather.hourly.map(h => `${weather.date}T${h.time.toString().padStart(4, '0')}`),
                    temperature_2m: weather.hourly.map(h => parseInt(h.tempC)),
                    weather_code: weather.hourly.map(h => convertWttrCode(h.weatherCode))
                },
                daily: {
                    time: data.weather.map(w => w.date),
                    weather_code: data.weather.map(w => convertWttrCode(w.hourly[4].weatherCode)),
                    temperature_2m_max: data.weather.map(w => parseInt(w.maxtempC)),
                    temperature_2m_min: data.weather.map(w => parseInt(w.mintempC)),
                    sunrise: data.weather.map(w => w.astronomy[0].sunrise),
                    sunset: data.weather.map(w => w.astronomy[0].sunset),
                    uv_index_max: data.weather.map(() => 5),
                    precipitation_sum: data.weather.map(w => parseFloat(w.totalSnow_cm) || 0),
                    wind_speed_10m_max: data.weather.map(w => parseInt(w.maxwindKmph))
                }
            };
        }
    } catch (error) {
        if (error.name !== 'AbortError') console.log('❌ BG wttr.in:', error.message);
    }
    return null;
}

async function fetchFrom7Timer(lat, lon) {
    try {
        console.log('🔄 BG: 7Timer...');
        const url = `https://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=civil&output=json`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        
        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'Accept': 'application/json' }
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ BG: 7Timer работает!');
            
            const now = new Date();
            
            return {
                current: {
                    temperature_2m: data.dataseries[0].temp2m,
                    relative_humidity_2m: data.dataseries[0].rh2m,
                    apparent_temperature: data.dataseries[0].temp2m,
                    wind_speed_10m: data.dataseries[0].wind10m.speed,
                    weather_code: convert7TimerCode(data.dataseries[0].weather),
                    pressure_msl: 1013
                },
                hourly: {
                    time: data.dataseries.slice(0, 24).map((h, i) => {
                        const time = new Date(now.getTime() + i * 3600000);
                        return time.toISOString();
                    }),
                    temperature_2m: data.dataseries.slice(0, 24).map(h => h.temp2m),
                    weather_code: data.dataseries.slice(0, 24).map(h => convert7TimerCode(h.weather))
                },
                daily: {
                    time: Array.from({length: 7}, (_, i) => {
                        const date = new Date(now.getTime() + i * 86400000);
                        return date.toISOString().split('T')[0];
                    }),
                    weather_code: Array.from({length: 7}, () => 0),
                    temperature_2m_max: Array.from({length: 7}, () => 20),
                    temperature_2m_min: Array.from({length: 7}, () => 10),
                    sunrise: Array.from({length: 7}, () => '06:00'),
                    sunset: Array.from({length: 7}, () => '20:00'),
                    uv_index_max: Array.from({length: 7}, () => 5),
                    precipitation_sum: Array.from({length: 7}, () => 0),
                    wind_speed_10m_max: Array.from({length: 7}, () => 10)
                }
            };
        }
    } catch (error) {
        if (error.name !== 'AbortError') console.log('❌ BG 7Timer:', error.message);
    }
    return null;
}

async function fetchWeatherData(lat, lon) {
    console.log('🌤️ BG: Начинаем загрузку...');
    
    // Запускаем ВСЕ API параллельно!
    const openMeteoPromise = fetchFromOpenMeteo(lat, lon);
    const wttrPromise = fetchFromWttr(lat, lon);
    const timerPromise = fetchFrom7Timer(lat, lon);
    
    try {
        const result = await Promise.any([
            openMeteoPromise.then(d => { if (!d) throw new Error(); return d; }),
            wttrPromise.then(d => { if (!d) throw new Error(); return d; }),
            timerPromise.then(d => { if (!d) throw new Error(); return d; })
        ]);
        
        return result;
    } catch (error) {
        throw new Error('Все API недоступны');
    }
}

function getBadgeColor(temp) {
    if (temp < 14) return '#2980b9';
    if (temp < 32) return '#3498db';
    if (temp < 50) return '#1abc9c';
    if (temp < 68) return '#2ecc71';
    if (temp < 86) return '#f39c12';
    return '#e74c3c';
}
async function updateBadgeFromCache() {
    try {
        const result = await chrome.storage.local.get(['weather_cache', 'unit_temp']);
        if (result.weather_cache && result.weather_cache.current) {
            const unit = result.unit_temp || 'c';
            const temp = result.weather_cache.current.temperature_2m;
            updateBadge(temp, unit);
        }
    } catch (error) {
        console.error('Background error:', error);
    }
}

function updateBadge(tempCelsius, unit = 'c') {
    let temp = Math.round(tempCelsius);
    
    if (unit === 'f') {
        temp = Math.round(tempCelsius * 9/5 + 32);
    }
    
    let badgeText = `${temp}°`;
    if (badgeText.length > 4) badgeText = badgeText.substring(0, 4);
    
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: getBadgeColor(temp) });
    chrome.action.setBadgeTextColor({ color: '#ffffff' });
}

function getBadgeColor(temp) {
    if (temp < -10) return '#2980b9';
    if (temp < 0) return '#3498db';
    if (temp < 10) return '#1abc9c';
    if (temp < 20) return '#2ecc71';
    if (temp < 30) return '#f39c12';
    return '#e74c3c';
}