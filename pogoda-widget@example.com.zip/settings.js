document.addEventListener('DOMContentLoaded', async () => {
    // Загружаем сохранённые настройки
    const result = await chrome.storage.local.get([
        'show_humidity',
        'show_wind',
        'show_pressure',
        'show_feels_like'
    ]);
    
    // Устанавливаем чекбоксы
    document.getElementById('show-humidity').checked = result.show_humidity !== false;
    document.getElementById('show-wind').checked = result.show_wind !== false;
    document.getElementById('show-pressure').checked = result.show_pressure !== false;
    document.getElementById('show-feels-like').checked = result.show_feels_like !== false;
    
    // Кнопка сохранения
    document.getElementById('save-btn').addEventListener('click', async () => {
        const settings = {
            show_humidity: document.getElementById('show-humidity').checked,
            show_wind: document.getElementById('show-wind').checked,
            show_pressure: document.getElementById('show-pressure').checked,
            show_feels_like: document.getElementById('show-feels-like').checked
        };
        
        await chrome.storage.local.set(settings);
        
        alert('✅ Настройки сохранены!');
        
        // Закрываем вкладку через 1 секунду
        setTimeout(() => {
            window.close();
        }, 1000);
    });
});